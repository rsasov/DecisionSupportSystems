--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.6
-- Dumped by pg_dump version 9.5.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: diagnosis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE diagnosis (
    d_id integer,
    s_id integer
);


ALTER TABLE diagnosis OWNER TO postgres;

--
-- Name: diseases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE diseases (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    advice character varying(150) NOT NULL,
    chronic boolean NOT NULL
);


ALTER TABLE diseases OWNER TO postgres;

--
-- Name: diseases_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE diseases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diseases_id_seq OWNER TO postgres;

--
-- Name: diseases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE diseases_id_seq OWNED BY diseases.id;


--
-- Name: symptoms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE symptoms (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    area character varying(50) NOT NULL
);


ALTER TABLE symptoms OWNER TO postgres;

--
-- Name: symptoms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE symptoms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE symptoms_id_seq OWNER TO postgres;

--
-- Name: symptoms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE symptoms_id_seq OWNED BY symptoms.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY diseases ALTER COLUMN id SET DEFAULT nextval('diseases_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY symptoms ALTER COLUMN id SET DEFAULT nextval('symptoms_id_seq'::regclass);


--
-- Data for Name: diagnosis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY diagnosis (d_id, s_id) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	6
1	7
1	9
2	8
2	11
2	10
2	2
2	4
2	3
2	7
2	12
3	13
3	16
3	14
3	3
3	11
3	15
3	12
4	8
4	17
4	18
4	2
4	7
4	19
1	19
2	19
5	7
5	13
5	1
5	19
5	11
5	14
5	20
6	1
6	6
6	21
6	7
7	11
7	12
7	18
7	3
7	9
7	7
7	19
6	5
\.


--
-- Data for Name: diseases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY diseases (id, name, advice, chronic) FROM stdin;
1	Flu	Self-treatment	f
2	Pneumonia	Visit your doctor	f
3	Diabetes Insipidus	Visit your doctor	t
4	Heart attack	Go to ER	f
5	Hangover	Self-treatment	f
6	Sinusitis	Visit your doctor	t
7	Food poisoning	Go to ER	f
\.


--
-- Name: diseases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('diseases_id_seq', 7, true);


--
-- Data for Name: symptoms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY symptoms (id, name, area) FROM stdin;
1	Headache	Head
2	Sweating	Whole body
3	Fever	Whole body
4	Cough	Head
5	Sore throat	Head
6	Nasal congestion	Head
7	Tiredness	Whole body
8	Chest pain	Chest
9	High Temperature	Whole body
10	Low Temperature	Whole body
12	Diarrhea	Stomach
13	Thirst	Head
14	Trouble sleeping	Whole body
15	Weight loss	Whole body
16	Fussiness	Whole body
11	Vomitting	Head
17	Heartburn	Chest
18	Abdominal pain	Abdominal
19	Dizziness	Whole body
20	Rapid heartbeat	Chest
21	Difficult breathing	Head
\.


--
-- Name: symptoms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('symptoms_id_seq', 21, true);


--
-- Name: diseases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY diseases
    ADD CONSTRAINT diseases_pkey PRIMARY KEY (id);


--
-- Name: symptoms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY symptoms
    ADD CONSTRAINT symptoms_pkey PRIMARY KEY (id);


--
-- Name: diagnosis_d_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY diagnosis
    ADD CONSTRAINT diagnosis_d_id_fkey FOREIGN KEY (d_id) REFERENCES diseases(id);


--
-- Name: diagnosis_s_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY diagnosis
    ADD CONSTRAINT diagnosis_s_id_fkey FOREIGN KEY (s_id) REFERENCES symptoms(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

